// // Slider 
// const slides = document.querySelector(".slides");
// const slide = document.querySelectorAll(".slides li");
// const prevBtn = document.querySelector(".prev");
// const nextBtn = document.querySelector(".next");

// let currentIdx = 0;
// let slideCount = slide.length;
// let slideWidth = 600;
// let slideMargin = 50;


// slides.style.width = (slideWidth + slideMargin) * slideCount - slideMargin + "px"

// function moveSlide(num) {
//   slides.style.left = -num * (slideWidth + slideMargin) + "px"
//   currentIdx = num;
// }

// nextBtn.addEventListener("click", () => {
//   if(currentIdx < slideCount - 3) {
//     moveSlide(currentIdx + 1);
//     console.log(currentIdx)
//   } else {
//     moveSlide(0)
//   }
// });

// prevBtn.addEventListener("click", () => {
//   if(currentIdx > 0) {
//     moveSlide(currentIdx - 1);
//   } else {
//     moveSlide(slideCount - 3)
//   }
// });





const bannerPrevBtn = document.querySelector('.banner_slide_prev_btn');
const bannerNextBtn = document.querySelector('.banner_slide_next_btn');
const bannerIndexNum = document.querySelector('.index_number')

bannerPrevBtn.addEventListener('clcik', () => {

})

function moveSlide() {

}

